﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewsBroadcast.Model
{
    public enum NewsCategory
    {
        Political,
        Sports,
        Crime,
        WorldWide,
        Bollywood
    }
    public enum Source
    {
        Internal,
        External
    }
    public class SourceType
    {
        public int SourceTypeId { get; set; }
        public string SourceTypeName { get; set; }//pti,google,
        public string Source { get; set; }//Internal,External
    }
   

}
