﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewsBrodcast.Model
{
    public class PageContent//1 element
    {
        public int PageNumber { get; set; }//1
        public string ContentType { get; set; }//News
        public string  ContentName { get; set; }//News1
        public int Priority { get; set; }//1
    }
}
