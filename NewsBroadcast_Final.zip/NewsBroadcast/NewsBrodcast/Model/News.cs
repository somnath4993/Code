﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewsBroadcast.Model
{
    public class News
    {
        public int NewsId { get; set; }
        public string NewsContent { get; set; }
        public string NewsCategory { get; set; }
        public int Priority { get; set; }
        public string  SourceType { get; set; }

        public bool UsedFlag { get; set; }




    }
}
