﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewsBrodcast.Model
{
    public class Page
    {
        public List<PageContent> ListPageContent { get; set; }//pageitems 8
    }
}
