﻿using NewsBroadcast.Model;
using NewsBrodcast.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NewsBroadcast.Controller
{
    public class DesignNewPagesController
    {
        List<PageContent> objPageContent = null;
        PageContent objPageContentItem = null;
        Page objPage = null;
        int pageDefinateItem = 8;
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public List<Page> DesignNewsPaper(List<News> listNews, List<Advertisement> listAdvertise)
        {

            List<Page> objPageLst = new List<Page>();
            int pageNo = 0;
            int NewsItem = 0;
            var filterHighPriorityNewsList = (from r in listNews where r.Priority == 1 && r.UsedFlag == false select r).ToList();

            int highCurrentCount = 0;
            //Push all High Prority News

            try
            {

                for (int index = 0; index < filterHighPriorityNewsList.Count; index++)
                {
                    highCurrentCount++;
                    if (index == 0 || NewsItem == pageDefinateItem)
                    {
                        objPageContent = new List<PageContent>();
                        pageNo++;
                        objPage = new Page();
                        NewsItem = 0;
                    }

                    News objNews = filterHighPriorityNewsList[index];
                    if (objNews != null)
                    {
                        objPageContentItem = new PageContent();
                        int indexvalueNews = listNews.IndexOf(objNews);
                        objPageContentItem.PageNumber = pageNo;
                        objPageContentItem.ContentType = "News";
                        objPageContentItem.ContentName = objNews.NewsContent;
                        objPageContentItem.Priority = objNews.Priority;
                        listNews[indexvalueNews].UsedFlag = true;
                        objPageContent.Add(objPageContentItem);
                        NewsItem++;
                    }
                    if (NewsItem == pageDefinateItem || highCurrentCount == filterHighPriorityNewsList.Count)
                    {
                        objPage.ListPageContent = objPageContent;//page property to list the content
                        objPageLst.Add(objPage);
                    }
                }

                //Proccess Remaining High Priority Item and Add the Advertisement
                objPageLst = ProcessHighPriorityNewsLastItem(objPageLst, listNews, listAdvertise);

                return objPageLst;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                return objPageLst;
            }

            ////write info on console if required
            //foreach (var item in objPageLst)
            //{
            //    objPageContent = new List<PageContent>();
            //    objPageContent = item.ListPageContent;
            //    foreach (var value in objPageContent)
            //    {
            //        Console.WriteLine("Page No " + value.PageNumber + " content type " + value.ContentType + " ContentName " + value.ContentName);
            //    }
            //}

            //Console.ReadLine();
            //return objPageLst;
        }

        List<Page> ProcessHighPriorityNewsLastItem(List<Page> objPageList, List<News> listNews, List<Advertisement> listAdvertise)
        {
            int pageNo = 0;
            int NewsItem = 0;
            int highLowCount = 0;
            var filterLowNewsList = (from r in listNews where r.Priority != 1 && r.UsedFlag == false select r).ToList();
            var filterPagelist = (from r in objPageList select r).ToList().LastOrDefault();
            try
            {


                if (filterPagelist != null)
                {
                    objPageContent = new List<PageContent>();
                    objPageContent = filterPagelist.ListPageContent;
                    var diffrenceValue = pageDefinateItem - objPageContent.Count;
                    if (objPageContent.Count != pageDefinateItem)//Check 8 Element 
                    {
                        NewsItem = objPageContent.Count;
                        pageNo = objPageList.Count;
                        if (diffrenceValue > 2)//Insert News
                        {
                            int newsCountToPushInLastPageContent = diffrenceValue - 2;

                            for (int cnt = 0; cnt < newsCountToPushInLastPageContent; cnt++)
                            {
                                highLowCount++;
                                News objNews = filterLowNewsList.Where(result => result.UsedFlag == false).FirstOrDefault();
                                if (objNews != null)
                                {
                                    int indexvalueNews = listNews.IndexOf(objNews);
                                    objPageContentItem = new PageContent();
                                    objPageContentItem.PageNumber = pageNo;
                                    objPageContentItem.ContentType = "News";
                                    objPageContentItem.ContentName = objNews.NewsContent;
                                    objPageContentItem.Priority = objNews.Priority;
                                    listNews[indexvalueNews].UsedFlag = true;
                                    objPageContent.Add(objPageContentItem);
                                    NewsItem++;
                                }
                                if (NewsItem == pageDefinateItem || highLowCount == newsCountToPushInLastPageContent)
                                {
                                    objPage.ListPageContent = objPageContent;//page property to list the content
                                    break;
                                }

                            }
                            for (int index = 0; index < 2; index++)
                            {
                                Advertisement objAdvertisement = listAdvertise.Where(result => result.AddUsedFlag == false).FirstOrDefault();
                                if (objAdvertisement != null)
                                {
                                    int indexvalueAdd = listAdvertise.IndexOf(objAdvertisement);
                                    objPageContentItem = new PageContent();
                                    objPageContentItem.PageNumber = pageNo;
                                    objPageContentItem.ContentType = "Advertise";
                                    objPageContentItem.ContentName = objAdvertisement.AdvertisementContent;
                                    objPageContentItem.Priority = objAdvertisement.Priority;
                                    listAdvertise[indexvalueAdd].AddUsedFlag = true;
                                    objPageContent.Add(objPageContentItem);

                                }

                            }
                        }
                        else
                        {
                            for (int index = 0; index < diffrenceValue; index++)
                            {
                                Advertisement objAdvertisement = listAdvertise.Where(result => result.AddUsedFlag == false).FirstOrDefault();
                                if (objAdvertisement != null)
                                {
                                    int indexvalueAdd = listAdvertise.IndexOf(objAdvertisement);
                                    objPageContentItem = new PageContent();
                                    objPageContentItem.PageNumber = pageNo;
                                    objPageContentItem.ContentType = "Advertise";
                                    objPageContentItem.ContentName = objAdvertisement.AdvertisementContent;
                                    objPageContentItem.Priority = objAdvertisement.Priority;
                                    listAdvertise[indexvalueAdd].AddUsedFlag = true;
                                    objPageContent.Add(objPageContentItem);
                                    if (index >= 1)
                                    {
                                        break;
                                    }
                                }

                            }
                        }

                    }


                }

                ProcessLowPriorityItem(objPageList, listNews, listAdvertise);
                return objPageList;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                return objPageList;
            }

        }

        List<Page> ProcessLowPriorityItem(List<Page> objPageList, List<News> listNews, List<Advertisement> listAdvertise)
        {
            int pageNo = objPageList.Count;
            int NewsItem = 0;

            int addCounter = 0;
            int highCurrentCount = 0;
            var FilterLowNewsList = (from r in listNews where r.Priority != 1 && r.UsedFlag == false select r).ToList();
            try
            {

                for (int cnt = 0; cnt < FilterLowNewsList.Count; cnt++)
                {
                    highCurrentCount++;

                    if (cnt == 0 || NewsItem == 6)
                    {
                        objPageContent = new List<PageContent>();
                        pageNo++;
                        objPage = new Page();
                        NewsItem = 0;
                    }

                    //To add Low news
                    News objNews = FilterLowNewsList[cnt];
                    if (objNews != null)
                    {
                        int indexvalueNews = listNews.IndexOf(objNews);
                        objPageContentItem = new PageContent();
                        objPageContentItem.PageNumber = pageNo;
                        objPageContentItem.ContentType = "News";
                        objPageContentItem.ContentName = objNews.NewsContent;
                        objPageContentItem.Priority = objNews.Priority;
                        listNews[indexvalueNews].UsedFlag = true;
                        objPageContent.Add(objPageContentItem);
                        NewsItem++;
                    }

                    if (NewsItem >= 6 || (FilterLowNewsList.Count == highCurrentCount))
                    {

                        for (int index = 0; index < listAdvertise.Count; index++)
                        {
                            Advertisement objAdvertisement = listAdvertise.Where(result => result.AddUsedFlag == false).FirstOrDefault();


                            if (objAdvertisement != null)
                            {
                                int indexvalue = listAdvertise.IndexOf(objAdvertisement);
                                objPageContentItem = new PageContent();
                                objPageContentItem.PageNumber = pageNo;
                                objPageContentItem.ContentType = "Advertise";
                                objPageContentItem.ContentName = objAdvertisement.AdvertisementContent;
                                objPageContentItem.Priority = objAdvertisement.Priority;
                                listAdvertise[indexvalue].AddUsedFlag = true;
                                objPageContent.Add(objPageContentItem);
                                addCounter++;
                                if (index >= 1)
                                {
                                    break;
                                }
                            }

                        }

                    }

                    if ((NewsItem == 6) || (FilterLowNewsList.Count == highCurrentCount))
                    {
                        objPage.ListPageContent = objPageContent;//page property to list the content
                        objPageList.Add(objPage);//List of Created Pages
                    }
                }

                return objPageList;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                return objPageList;
            }

            
        }


    }
}
