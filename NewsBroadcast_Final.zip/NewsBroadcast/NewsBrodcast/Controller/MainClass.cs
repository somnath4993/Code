﻿using NewsBroadcast.Model;
using NewsBrodcast.DataHelper;
using NewsBrodcast.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewsBroadcast.Controller
{
   public class MainClass
    {

        static void Main(string[] args)
        {
            DataManager datamanager = new DataManager();
            DesignNewPagesController pageController = new DesignNewPagesController();
            List<News> newsList = datamanager.GetListOfNews();
            List<Advertisement> AddList = datamanager.GetAdvertisementList();
            // pageController.DesignNewsPaperPages(newsList, AddList);
            pageController.DesignNewsPaper(newsList, AddList);


        }
    }
}
