﻿using NewsBrodcast.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NewsBroadcast.Model;

namespace NewsBroadcast.Controller
{
    public class SourceController : ISource
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
       public string AddSource(Source obj)
        {
            try
            {
                /*
                 Assumption :-
                 here we are adding source
                 calling database helper or WCF Service code
                 */
                return "Source Added Successfully";
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                return string.Empty;
            }
            
            
        }
    }
}
