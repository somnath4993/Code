﻿using NewsBroadcast.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NewsBroadcast.Model;

namespace NewsBroadcast.Controller
{
    public class NewsController : INews
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public string AddNewsContent(News obj)
        {
            try
            {
                /*
                Assumption :-
                here we writing database code, calling helper of WCF Service
                and after successfull news add we return message
                */
                return "News Added Successfully";
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                return string.Empty;
            }
            
        }

       public string DeleteNewsContent(int newsID)
        {
            try
            {
                /*
               Assumption :-
               here we writing database code, calling helper of WCF Service
               and after successfull news delete we return message
               */
                return "News Deleted Successfully";
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                return string.Empty;
            }
            
        }

       
    }
}
