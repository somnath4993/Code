﻿using NewsBroadcast.Model;
using NewsBrodcast.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewsBroadcast.Controller
{
    
    public class AdvertisementController : IAdvertise
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public string Add_Advertise(Advertisement advertisement)
        {
            try
            {
                /*
                Assumption :-
                here we writing database code, calling helper of WCF Service
                and after successfull news add we return message
                */
                return "Advertise Added Successfully";
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                return string.Empty;
            }
        }

        public string Delete_Advertise(int AdvertisementID)
        {
            try
            {
                /*
                Assumption :-
                here we writing database code, calling helper of WCF Service
                and after successfull news add we return message
                */
                return "Advertise Deleted Successfully";
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                return string.Empty;
            }
        }
    }
}
