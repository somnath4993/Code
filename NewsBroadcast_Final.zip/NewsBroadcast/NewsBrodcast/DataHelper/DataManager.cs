﻿using NewsBroadcast.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewsBrodcast.DataHelper
{
   public class DataManager
    {
        //this is just dummy data for execution checking
        public List<News> GetListOfNews()
        {
            List<News> list = new List<News>();
            list.Add(new News { NewsId = 1, NewsContent = "News1", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.Internal.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 2, NewsContent = "News2", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.External.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 3, NewsContent = "News3", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.Internal.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 4, NewsContent = "News4", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.External.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 5, NewsContent = "News5", NewsCategory = NewsCategory.Political.ToString(), Priority = 2, SourceType = Source.Internal.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 6, NewsContent = "News6", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.External.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 7, NewsContent = "News7", NewsCategory = NewsCategory.Political.ToString(), Priority = 2, SourceType = Source.Internal.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 8, NewsContent = "News8", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.External.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 9, NewsContent = "News9", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.External.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 10, NewsContent = "News10", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.External.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 11, NewsContent = "News11", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.External.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 12, NewsContent = "News12", NewsCategory = NewsCategory.Political.ToString(), Priority = 2, SourceType = Source.Internal.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 13, NewsContent = "News13", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.External.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 14, NewsContent = "News14", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.Internal.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 15, NewsContent = "News15", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.External.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 16, NewsContent = "News16", NewsCategory = NewsCategory.Political.ToString(), Priority = 1, SourceType = Source.External.ToString(), UsedFlag = false });
            list.Add(new News { NewsId = 17, NewsContent = "News17", NewsCategory = NewsCategory.Political.ToString(), Priority = 2, SourceType = Source.External.ToString(), UsedFlag = false });
            return list;
        }

        public List<Advertisement> GetAdvertisementList()
        {
            List<Advertisement> list = new List<Advertisement>();
            list.Add(new Advertisement { AdvertisementId = 1, AdvertisementContent = "Advertisement1", Priority = 1, AddUsedFlag = false });
            list.Add(new Advertisement { AdvertisementId = 2, AdvertisementContent = "Advertisement2", Priority = 1, AddUsedFlag = false });
            list.Add(new Advertisement { AdvertisementId = 3, AdvertisementContent = "Advertisement3", Priority = 1, AddUsedFlag = false });
            list.Add(new Advertisement { AdvertisementId = 4, AdvertisementContent = "Advertisement4", Priority = 1, AddUsedFlag = false });
            list.Add(new Advertisement { AdvertisementId = 5, AdvertisementContent = "Advertisement5", Priority = 2, AddUsedFlag = false });
            list.Add(new Advertisement { AdvertisementId = 6, AdvertisementContent = "Advertisement6", Priority = 2, AddUsedFlag = false });
            list.Add(new Advertisement { AdvertisementId = 7, AdvertisementContent = "Advertisement6", Priority = 2, AddUsedFlag = false });
            list.Add(new Advertisement { AdvertisementId = 8, AdvertisementContent = "Advertisement7", Priority = 1, AddUsedFlag = false });

            return list;
        }
    }
}
