﻿using NewsBroadcast.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewsBrodcast.Interface
{
    public interface IAdvertise
    {
       string Add_Advertise(Advertisement advertisement);
       string Delete_Advertise(int AdvertisementID);
    }
}
