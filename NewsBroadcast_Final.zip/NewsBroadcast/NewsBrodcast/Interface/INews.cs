﻿using NewsBroadcast.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewsBroadcast.Interface
{
    public interface INews
    {
       string  AddNewsContent(News obj);
       string DeleteNewsContent(int newsID);
    }
}
