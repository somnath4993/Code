﻿using NewsBroadcast.Model;
using System;
using TechTalk.SpecFlow;
using NewsBroadcast.Controller;
using NewsBroadcast.Interface;
using NUnit.Framework;
using NewsBrodcast.Interface;
using NewsBrodcast.DataHelper;
using System.Collections.Generic;
using NewsBrodcast.Model;

namespace UnitTesting.StepDefinition
{
    [Binding]
    public class SpecFlowFeature1Steps
    {
        private string actualNewsAddResult;
        private string actualNewsDeleteResult;
        private string actualSourceAddResult;
        private int pageCount;
        List<Page> pageList;
        [Given(@"Source should be loggedin")]
        public void GivenSourceShouldBeLoggedin()
        {
            Assert.True(true);//assume user is logged in
        }

        [When(@"Add a new News")]
        public void WhenAddANewNews()
        {
            //create mock object of news
            News news = new News();
            INews inews = new NewsController();
            actualNewsAddResult = inews.AddNewsContent(news);
        }


        [Then(@"New News should be Added and success message should come")]
        public void ThenNewNewsShouldBeAddedAndSuccessMessageShouldCome(Table table)
        {
            string expectedMessage = table.Rows[0]["Message"].ToString().Trim();
            Assert.AreEqual(expectedMessage, actualNewsAddResult);
        }

        [When(@"Delete a old news")]
        public void WhenDeleteAOldNews()
        {
            INews inews = new NewsController();
            //send Dummy NewsID
            int newsID = 0;
            actualNewsDeleteResult = inews.DeleteNewsContent(newsID);
        }


        [Then(@"New News should be deleted and success message should come")]
        public void ThenNewNewsShouldBeDeletedAndSuccessMessageShouldCome(Table table)
        {
            string expectedMessage = table.Rows[0]["Message"].ToString().Trim();
            Assert.AreEqual(expectedMessage, actualNewsDeleteResult);
        }

        [Given(@"Admin should be loggedin")]
        public void GivenAdminShouldBeLoggedin()
        {
            Assert.True(true);//assume Admin is logged in
        }

        [When(@"Add new source")]
        public void WhenAddNewSource()
        {
            ISource iSource = new SourceController();
            //create mock object of Source
            Source source = new Source();
            actualSourceAddResult = iSource.AddSource(source);
        }

        [Then(@"Add  should be added and success message should come")]
        public void ThenAddShouldBeAddedAndSuccessMessageShouldCome(Table table)
        {
            string expectedMessage = table.Rows[0]["Message"].ToString().Trim();
            Assert.AreEqual(expectedMessage, actualSourceAddResult);
        }


        [Given(@"News Page creator should be loggedin")]
        public void GivenNewsPageCreatorShouldBeLoggedin()
        {
            //Assume page creator should be loggedin
            Assert.True(true);
        }

        [When(@"News Pages created successfully")]
        public void WhenNewsPagesCreatedSuccessfully()
        {
            DesignNewPagesController designNewsPage = new DesignNewPagesController();
            DataManager datamanager = new DataManager();
            List<News> newslist = datamanager.GetListOfNews();
            List<Advertisement> advertisementlist = datamanager.GetAdvertisementList();
            pageList= designNewsPage.DesignNewsPaper(newslist, advertisementlist);
            pageCount = pageList.Count;
        }

        [Then(@"Number of page should be return")]
        public void ThenNumberOfPageShouldBeReturn()
        {
            //here we know the how many pages we have so paasing hardcode value to validate
            int expectedPageCount = 3;
            Assert.AreEqual(expectedPageCount, pageCount);
        }

        [Then(@"News Page should be return")]
        public void ThenNewsPageShouldBeReturn()
        {
            //as per buisness rule one page content 8 items, News/Advertisment
            int expectedPageItem = 8;
            if(pageList.Count>0)
            {

                List<PageContent> pageContent = pageList[0].ListPageContent;
                if(pageContent.Count== expectedPageItem)
                {
                    Assert.True(true);
                }
                else
                {
                    Assert.IsFalse(false);
                }
            }
                
        }


    }
}
